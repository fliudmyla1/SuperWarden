import {
  h,
  render
} from "./chunk-YHK7COGI.js";
import {
  __spreadValues
} from "./chunk-LJBNGPO3.js";

// node_modules/@meforma/vue-toaster/src/index.js
import Toaster2 from "E:/nft/work/client/node_modules/@meforma/vue-toaster/src/Toaster.vue";

// node_modules/@meforma/vue-toaster/src/api.js
import Toaster from "E:/nft/work/client/node_modules/@meforma/vue-toaster/src/Toaster.vue";

// node_modules/@meforma/vue-toaster/src/helpers/event-bus.js
var Event = class {
  constructor() {
    this.queue = {};
  }
  $on(name, callback) {
    this.queue[name] = this.queue[name] || [];
    this.queue[name].push(callback);
  }
  $off(name, callback) {
    if (this.queue[name]) {
      for (var i = 0; i < this.queue[name].length; i++) {
        if (this.queue[name][i] === callback) {
          this.queue[name].splice(i, 1);
          break;
        }
      }
    }
  }
  $emit(name, data) {
    if (this.queue[name]) {
      this.queue[name].forEach(function(callback) {
        callback(data);
      });
    }
  }
};
var event_bus_default = new Event();

// node_modules/@meforma/vue-toaster/src/helpers/mount-component.js
var createElement = () => typeof document !== "undefined" && document.createElement("div");
var mount = (component, { props, children, element, app } = {}) => {
  let el = element ? element : createElement();
  let vNode = h(component, props, children);
  if (app && app._context) {
    vNode.appContext = app._context;
  }
  render(vNode, el);
  const destroy = () => {
    if (el) {
      render(null, el);
    }
    el = null;
    vNode = null;
  };
  return { vNode, destroy, el };
};
var mount_component_default = mount;

// node_modules/@meforma/vue-toaster/src/api.js
var Api = (globalOptions = {}) => {
  return {
    show(message, options = {}) {
      let localOptions = __spreadValues({ message }, options);
      const c = mount_component_default(Toaster, {
        props: __spreadValues(__spreadValues({}, globalOptions), localOptions)
      });
      return c;
    },
    clear() {
      event_bus_default.$emit("toast-clear");
    },
    success(message, options = {}) {
      options.type = "success";
      return this.show(message, options);
    },
    error(message, options = {}) {
      options.type = "error";
      return this.show(message, options);
    },
    info(message, options = {}) {
      options.type = "info";
      return this.show(message, options);
    },
    warning(message, options = {}) {
      options.type = "warning";
      return this.show(message, options);
    }
  };
};
var api_default = Api;

// node_modules/@meforma/vue-toaster/src/defaults/positions.js
var POSITIONS = {
  TOP_RIGHT: "top-right",
  TOP: "top",
  TOP_LEFT: "top-left",
  BOTTOM_RIGHT: "bottom-right",
  BOTTOM: "bottom",
  BOTTOM_LEFT: "bottom-left"
};
var positions_default = Object.freeze(POSITIONS);

// node_modules/@meforma/vue-toaster/src/index.js
var Plugin = (app, options = {}) => {
  let methods = api_default(options);
  app.$toast = methods;
  app.config.globalProperties.$toast = methods;
};
Toaster2.install = Plugin;
var src_default = Toaster2;

// dep:@meforma_vue-toaster
var meforma_vue_toaster_default = src_default;
export {
  positions_default as Positions,
  Toaster2 as Toaster,
  api_default as createToaster,
  meforma_vue_toaster_default as default
};
//# sourceMappingURL=@meforma_vue-toaster.js.map
