import {
  Teleport,
  Transition,
  computed,
  createBaseVNode,
  createBlock,
  createCommentVNode,
  createVNode,
  defineComponent,
  inject,
  mergeProps,
  nextTick,
  normalizeClass,
  normalizeStyle,
  onMounted,
  onUnmounted,
  openBlock,
  readonly,
  ref,
  renderSlot,
  toHandlers,
  toRefs,
  vShow,
  watch,
  withCtx,
  withDirectives,
  withModifiers
} from "./chunk-YHK7COGI.js";
import {
  __spreadValues
} from "./chunk-LJBNGPO3.js";

// node_modules/vue-universal-modal/dist/index.es.js
var A = ({ modalRef: n2, latest: a2, show: s2 }) => {
  let i2;
  function r2(e2) {
    const t2 = e2.target.closest(`.${R}`);
    if (!a2.value)
      return;
    if (!t2 || t2 !== n2.value) {
      if (t2 && !t2.classList.contains(`${R}-show`))
        return;
      i2 = e2.target;
    }
  }
  function u2(e2) {
    if (e2) {
      if (n2.value)
        n2.value.focus();
    } else if (i2)
      i2.focus();
  }
  onMounted(() => {
    document.addEventListener("click", r2);
    watch(() => s2.value, (e2) => {
      nextTick(() => u2(e2));
    }, { immediate: s2.value });
  });
  onUnmounted(() => {
    document.removeEventListener("click", r2);
  });
};
var L = ({ close: t2, closeClickDimmed: o2, closeKeyCode: n2, latest: a2 }) => {
  let s2 = null;
  function i2(e2) {
    s2 = e2.target;
  }
  function r2(e2) {
    if (o2 && s2 === e2.target)
      t2.value();
    s2 = null;
  }
  function u2(e2) {
    if (e2.keyCode === n2 && a2.value)
      t2.value();
  }
  onMounted(() => {
    if (n2)
      document.addEventListener("keyup", u2);
  });
  onUnmounted(() => {
    if (n2)
      document.removeEventListener("keyup", u2);
  });
  return { onMouseDownDimmed: i2, onMouseUpDimmed: r2 };
};
var S = ({ modalRef: e2, show: l2 }) => {
  const { visibleModals: s2, addVisibleModals: i2, removeVisibleModals: r2 } = inject(N);
  const u2 = computed(() => {
    const t2 = [...s2.value.values()];
    if (!t2.length || !e2.value)
      return false;
    return t2[t2.length - 1] === e2.value;
  });
  watch(() => l2.value, () => {
    nextTick(() => {
      if (!e2.value)
        return;
      if (l2.value)
        i2(e2.value);
      else
        r2(e2.value);
    });
  }, { immediate: true });
  return { latest: u2 };
};
var _ = (() => ".vue-universal-modal-leave-from,.vue-universal-modal-enter-to{opacity:1}.vue-universal-modal-enter-from,.vue-universal-modal-leave-to{opacity:0}.vue-universal-modal{-webkit-overflow-scrolling:touch;overscroll-behavior:contain;position:fixed;overflow-y:auto;left:0;top:0;right:0;bottom:0;background-color:#000c;text-align:left}.vue-universal-modal:not(.vue-universal-modal-latest){background:none}.vue-universal-modal-content{display:flex;flex-direction:column;align-items:center;justify-content:center;width:100%;min-height:100%}\n")();
var $ = (e2, t2) => {
  const o2 = e2.__vccOpts || e2;
  for (const [e3, l2] of t2)
    o2[e3] = l2;
  return o2;
};
var T = defineComponent({ inheritAttrs: false, props: { close: { type: Function, default: () => {
} }, disabled: { type: Boolean, default: false }, modelValue: { type: Boolean, default: true }, options: { type: Object, default: () => ({}) } }, emits: ["before-enter", "enter", "after-enter", "enter-cancelled", "before-leave", "leave", "after-leave", "leave-cancelled"], setup(e2, o2) {
  const { teleportTarget: l2 } = inject(N);
  const { close: a2, disabled: s2, options: u2, modelValue: d2 } = toRefs(e2);
  const c2 = ref(d2.value === void 0 ? true : d2.value);
  const v2 = ref(null);
  const m2 = ref(!s2.value);
  const f2 = __spreadValues({ transition: 300, closeClickDimmed: true, closeKeyCode: 27, styleModalContent: {} }, u2.value);
  watch([() => d2.value, () => s2.value], () => {
    const e3 = d2.value && !s2.value;
    m2.value = e3;
    if (d2.value)
      c2.value = d2.value;
  }, { immediate: true });
  const { latest: p2 } = S({ modalRef: v2, show: m2 });
  A({ latest: p2, modalRef: v2, show: m2 });
  const { onMouseDownDimmed: M2, onMouseUpDimmed: b2 } = L({ close: a2, closeClickDimmed: f2.closeClickDimmed, closeKeyCode: f2.closeKeyCode, latest: p2 });
  const C2 = { beforeEnter: () => o2.emit("before-enter"), enter: () => o2.emit("enter"), afterEnter: () => o2.emit("after-enter"), enterCancelled: () => o2.emit("enter-cancelled"), beforeLeave: () => o2.emit("before-leave"), leave: () => o2.emit("leave"), afterLeave: () => {
    o2.emit("after-leave");
    if (d2.value === false)
      c2.value = false;
  }, leaveCancelled: () => o2.emit("leave-cancelled") };
  const w2 = () => {
    if (a2.value)
      a2.value();
  };
  return { CLASS_NAME: R, emitClose: w2, inserted: c2, latest: p2, mergeOptions: f2, modalRef: v2, onMouseDownDimmed: M2, onMouseUpDimmed: b2, onTransitionEmit: C2, show: m2, teleportTarget: l2, transition: f2.transition ? f2.transition / 1e3 + "s" : void 0 };
} });
function V(e2, t2, o2, l2, n2, a2) {
  return e2.inserted ? (openBlock(), createBlock(Teleport, { key: 0, to: e2.teleportTarget, disabled: e2.disabled }, [createVNode(Transition, mergeProps({ appear: "", name: e2.CLASS_NAME }, toHandlers(e2.onTransitionEmit)), { default: withCtx(() => {
    var _a;
    return [withDirectives(createBaseVNode("div", mergeProps({ ref: "modalRef", role: "dialog", tabindex: "-1", "aria-modal": "true", "aria-label": "Modal window", class: [e2.CLASS_NAME, { [`${e2.CLASS_NAME}-show`]: e2.show }, { [`${e2.CLASS_NAME}-latest`]: e2.latest }], style: { transitionDuration: e2.transition } }, e2.$attrs), [createBaseVNode("div", { class: normalizeClass(`${e2.CLASS_NAME}-content`), style: normalizeStyle(__spreadValues({ transitionDuration: e2.transition }, (_a = e2.mergeOptions) == null ? void 0 : _a.styleModalContent)), onMousedown: t2[0] || (t2[0] = withModifiers((...t3) => e2.onMouseDownDimmed && e2.onMouseDownDimmed(...t3), ["self"])), onMouseup: t2[1] || (t2[1] = (...t3) => e2.onMouseUpDimmed && e2.onMouseUpDimmed(...t3)) }, [renderSlot(e2.$slots, "default", { emitClose: e2.emitClose }), renderSlot(e2.$slots, "close")], 38)], 16), [[vShow, e2.show]])];
  }), _: 3 }, 16, ["name"])], 8, ["to", "disabled"])) : createCommentVNode("", true);
}
var x = $(T, [["render", V]]);
var N = "VueUniversalModal";
var R = "vue-universal-modal";
var U = (e2, t2 = {}) => {
  const { teleportTarget: o2 = "", teleportComponent: l2 = "", teleportComponentId: n2 = "", modalComponent: a2 = "Modal" } = t2;
  if (!o2)
    return;
  if (l2 || n2)
    return;
  const s2 = ref(new Set());
  const i2 = (e3) => {
    s2.value.add(e3);
  };
  const u2 = (e3) => {
    s2.value.delete(e3);
  };
  e2.provide(N, { teleportTarget: o2, visibleModals: readonly(s2), addVisibleModals: i2, removeVisibleModals: u2 });
  e2.component(a2, x);
};
var K = { install: U };

// dep:vue-universal-modal
var vue_universal_modal_default = K;
export {
  R as CLASS_NAME,
  N as PLUGIN_NAME,
  vue_universal_modal_default as default
};
//# sourceMappingURL=vue-universal-modal.js.map
