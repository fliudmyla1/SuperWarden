export const murmur332: import("multiformats/hashes/hasher").Hasher<"murmur3-32", 35>;
export const murmur3128: import("multiformats/hashes/hasher").Hasher<"murmur3-128", 34>;
//# sourceMappingURL=index.d.ts.map