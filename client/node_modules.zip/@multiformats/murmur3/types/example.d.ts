export {};
//# sourceMappingURL=example.d.ts.map