export declare function isPerformanceSupported(): boolean;
export declare function now(): number;
