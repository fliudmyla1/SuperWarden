# Installation
> `npm install --save @types/long`

# Summary
This package contains type definitions for long.js (https://github.com/dcodeIO/long.js).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/long.

### Additional Details
 * Last updated: Tue, 26 Apr 2022 19:31:52 GMT
 * Dependencies: none
 * Global values: `Long`

# Credits
These definitions were written by [Peter Kooijmans](https://github.com/peterkooijmans).
