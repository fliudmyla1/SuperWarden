/**
 * Query Buidler
 * @param {string} baseUrl
 * @param {*} filters
 * @returns {*}
 */
export default function queryBuilder(baseUrl: string, filters: any): any;
