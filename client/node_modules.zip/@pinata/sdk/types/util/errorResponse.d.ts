export function handleError(error: any): any;
