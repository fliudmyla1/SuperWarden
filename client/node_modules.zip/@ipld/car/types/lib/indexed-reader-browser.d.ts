export class CarIndexedReader {
    static fromFile(): Promise<void>;
}
export const __browser: true;
//# sourceMappingURL=indexed-reader-browser.d.ts.map