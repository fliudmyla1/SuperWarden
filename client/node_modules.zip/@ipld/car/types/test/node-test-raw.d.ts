export type Block = import('../api').Block;
//# sourceMappingURL=node-test-raw.d.ts.map