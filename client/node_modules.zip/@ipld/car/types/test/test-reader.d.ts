export {};
//# sourceMappingURL=test-reader.d.ts.map