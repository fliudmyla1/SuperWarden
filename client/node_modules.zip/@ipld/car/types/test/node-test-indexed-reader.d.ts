export {};
//# sourceMappingURL=node-test-indexed-reader.d.ts.map