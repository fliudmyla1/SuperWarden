export {};
//# sourceMappingURL=test-indexer.d.ts.map