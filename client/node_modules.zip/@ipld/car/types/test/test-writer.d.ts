export type Block = import('../api').Block;
//# sourceMappingURL=test-writer.d.ts.map