export type CID = import('multiformats').CID;
export type Block = import('../api').Block;
//# sourceMappingURL=node-test-file-streams.d.ts.map