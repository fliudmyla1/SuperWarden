export {};
//# sourceMappingURL=test-interface.d.ts.map