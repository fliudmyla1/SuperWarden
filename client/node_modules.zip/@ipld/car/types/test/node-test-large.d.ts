export type BlockIndex = import('../api').BlockIndex;
//# sourceMappingURL=node-test-large.d.ts.map