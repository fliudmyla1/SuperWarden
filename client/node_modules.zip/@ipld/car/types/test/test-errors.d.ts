export {};
//# sourceMappingURL=test-errors.d.ts.map