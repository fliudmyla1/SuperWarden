module.exports = require('./cjs/src/index.js')
